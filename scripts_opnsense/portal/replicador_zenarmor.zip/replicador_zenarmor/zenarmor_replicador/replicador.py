#!/usr/local/bin/python3

import requests
import socket
import time
import json
import sys
import logging
from datetime import datetime, timedelta

# 🎛️ Modos de execução
DEBUG = '--debug' in sys.argv
FORCAR_TUDO = '--tudo' in sys.argv

# 📁 Logging
logging.basicConfig(
    filename='/var/log/replicador.log',
    level=logging.INFO,
    format='%(asctime)s — %(levelname)s — %(message)s'
)

def log_info(msg):
    logging.info(msg)
    if DEBUG:
        print(f"[INFO] {msg}")

def log_error(msg):
    logging.error(msg)
    print(f"[ERRO] {msg}")

# 🚀 Configurações
local_url = "http://localhost:9200"
externo_url = "http://172.18.25.252:9200"
index_destino = "zenarmor-metricas"
prefixo = "zenarmor_"
intervalo_segundos = 300

hostname = socket.getfqdn()
log_info(f"🖥️ Replicador iniciado para host: {hostname}")
log_info("🌐 Envio para índice unificado: zenarmor-metricas")
if FORCAR_TUDO:
    log_info("🔁 Modo --tudo ativado: enviando todos os dados históricos!")

while True:
    try:
        agora = datetime.utcnow()
        if FORCAR_TUDO:
            inicio_intervalo = "2000-01-01T00:00:00Z"
        else:
            inicio_intervalo = (agora - timedelta(seconds=intervalo_segundos)).isoformat()

        log_info(f"📅 Buscando documentos com start_time > {inicio_intervalo}")

        res = requests.get(f"{local_url}/_cat/indices?h=index&format=json")
        todos_indices = [i['index'] for i in res.json() if i['index'].startswith(prefixo)]

        if not todos_indices:
            log_info("⚠️ Nenhum índice local encontrado.")
            time.sleep(intervalo_segundos)
            continue

        consulta = {
            "size": 1000,
            "query": {
                "range": {
                    "start_time": { "gt": inicio_intervalo }
                }
            }
        }

        total_enviados = 0

        for indice_origem in todos_indices:
            log_info(f"📦 Consultando índice local: {indice_origem}")
            r = requests.post(f"{local_url}/{indice_origem}/_search", json=consulta)
            if r.status_code != 200:
                log_error(f"❌ Falha ao consultar {indice_origem}: {r.status_code}")
                continue

            docs = r.json().get("hits", {}).get("hits", [])
            log_info(f"🔎 {len(docs)} documentos encontrados.")

            for doc in docs:
                source = doc["_source"]

                # Garantir @timestamp
                if "start_time" in source:
                    valor = source["start_time"]
                    if isinstance(valor, (int, float)):
                        dt = datetime.utcfromtimestamp(valor / 1000)
                        source["@timestamp"] = dt.isoformat() + "Z"
                    else:
                        source["@timestamp"] = valor

                # ✅ Novo: garantir FQDN como src_hostname
                source["src_hostname"] = hostname

                # Enviar para índice unificado com pipeline
                destino_url = f"{externo_url}/{index_destino}/_doc?pipeline=zenarmor_pipeline"
                resp = requests.post(destino_url, json=source)

                if resp.status_code in [200, 201]:
                    total_enviados += 1
                else:
                    log_error(f"⚠️ Erro ao enviar doc: {resp.status_code} — {resp.text}")

        log_info(f"✅ Replicação concluída: {total_enviados} documentos enviados.")
        if FORCAR_TUDO:
            log_info("🛑 Execução finalizada após carga total (--tudo).")
            break

        time.sleep(intervalo_segundos)

    except Exception as e:
        log_error(f"💥 Exceção inesperada: {e}")
        time.sleep(intervalo_segundos)