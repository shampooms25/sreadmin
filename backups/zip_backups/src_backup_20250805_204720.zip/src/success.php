<?php
// filepath: success.php

// Recebe os dados enviados via POST
$username = $_POST['username'] ?? '';
$video = $_POST['video'] ?? '';

require_once 'db_connect.php';

$mensagem = '';
if ($username && $video) {
    $result = pg_query_params(
        $conn,
        "INSERT INTO eld_registro_view_videos (username, video) VALUES ($1, $2)",
        [$username, $video]
    );
    if ($result) {
        $mensagem = "<span style='color:green;'>Registro salvo com sucesso!</span>";
    } else {
        $mensagem = "<span style='color:red;'>Erro ao salvar registro.</span>";
    }
} else {
    $mensagem = "<span style='color:red;'>Dados insuficientes para registro.</span>";
}
?>
<!DOCTYPE html>
<html lang="pt-BR">

<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="robots" content="noindex,nofollow" />
    <title>Registro de Visualização</title>

    <link href="css/bootstrap.min.css" rel="stylesheet" />
    <link href="css/login.css" rel="stylesheet" />

    <style>
        html,
        body {
            height: 100%;
            margin: 0;
        }

        body {
            display: flex;
            align-items: center;
            justify-content: center;
            background-image: url('images/bg_eucalipto.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center center;
            background-attachment: fixed;
        }

        .panel {
            background-color: rgba(255, 255, 255, 0.8);
            border-radius: 8px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
            width: 100%;
            max-width: 400px;
        }

        .panel-heading {
            border-top-left-radius: 8px;
            border-top-right-radius: 8px;
            background-color: rgba(92, 184, 92, 0.8);
            padding: 10px;
        }

        .panel-body {
            padding: 25px;
        }
    </style>
</head>

<body>
    <div class="panel panel-info">
        <div class="panel-heading text-center">
            <div class="panel-title">
                <img src="images/logo-eldorado.png" alt="logo" height="48" />
            </div>
        </div>
        <div class="panel-body text-center">
            <h4>Registro de Visualização</h4>
            <p><strong>Usuário:</strong> <?php echo htmlspecialchars($username); ?></p>
            <p><strong>Vídeo:</strong> <?php echo htmlspecialchars($video); ?></p>
            <p style="margin-top:30px;"><?php echo $mensagem; ?></p>
        </div>
    </div>
</body>
</html>