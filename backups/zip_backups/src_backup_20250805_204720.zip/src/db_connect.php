<?php
// filepath: db_connect.php

$host = 'localhost';
$db   = 'radius';
$user = 'radius';
$pass = '123';
$port = '5432';

$conn = pg_connect("host=$host port=$port dbname=$db user=$user password=$pass");
if (!$conn) {
    die("Erro ao conectar ao banco de dados PostgreSQL.");
}
?>