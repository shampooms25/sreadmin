// This file manages the authentication logic for the hotspot authentication page.
// It checks if the video has been fully watched before redirecting the user to the login page
// and retrieves the saved playback position from local storage.

document.addEventListener('DOMContentLoaded', () => {
    const video = document.getElementById('authVideo');
    const loginButton = document.getElementById('loginButton');

    // Verificar se o vídeo foi carregado corretamente
    if (!video) {
        console.error('Video element not found');
        return;
    }

    // Verificar se já assistiu o vídeo
    const videoWatchKey = `video_watched_${getDeviceId()}`;
    const watchData = localStorage.getItem(videoWatchKey);

    if (watchData) {
        const watchInfo = JSON.parse(watchData);
        if (!watchInfo.completed) {
            // Se não completou o vídeo, restaurar progresso
            if (watchInfo.progress) {
                video.currentTime = watchInfo.progress;
            }
        }
    }

    // Event listener para atualização do tempo do vídeo
    video.addEventListener('timeupdate', () => {
        saveVideoProgress(false);
    });

    // Event listener para fim do vídeo
    video.addEventListener('ended', () => {
        saveVideoProgress(true);
        // Habilitar botão de autenticação
        const authButton = document.getElementById('authButton');
        if (authButton) {
            authButton.style.display = 'block';
            setTimeout(() => {
                authButton.classList.add('visible');
            }, 100);
        }
    });

    // Handler do botão de autenticação
    const authButton = document.getElementById('authButton');
    if (authButton) {
        authButton.addEventListener('click', () => {
            try {
                const params = new URLSearchParams(window.location.search);
                const zone = params.get('zone');
                const portalURL = params.get('redirurl');

                if (zone) {
                    window.location.href = `./login2.html?zone=${zone}&redirurl=${encodeURIComponent(portalURL || '')}`;
                } else {
                    window.location.href = 'login2.html';
                }
            } catch (error) {
                console.error('Error redirecting:', error);
                window.location.href = 'login2.html';
            }
        });
    }

    // Remover o listener de submit do formulário antigo
    const loginForm = document.getElementById('loginForm');
    if (loginForm) {
        loginForm.removeEventListener('submit', null);
    }
});

// Função auxiliar para salvar progresso
function saveVideoProgress(completed = false) {
    try {
        const video = document.getElementById('authVideo');
        const deviceId = getDeviceId();
        const videoWatchKey = `video_watched_${deviceId}`;
        
        const watchInfo = {
            timestamp: Date.now(),
            completed: completed,
            progress: video.currentTime,
            duration: video.duration
        };
        
        localStorage.setItem(videoWatchKey, JSON.stringify(watchInfo));
    } catch (error) {
        console.error('Error saving progress:', error);
    }
}

window.addEventListener('pageshow', function(event) {
    if (event.persisted) {
        // Página carregada do cache (botão voltar)
        window.location.reload();
    }
});