document.addEventListener('DOMContentLoaded', () => {
    setTimeout(() => {
        const player = new Plyr('#authVideo', {
            controls: ['play-large', 'play', 'mute', 'volume', 'fullscreen']
        });

        // Função para redirecionar para login2.html
        const video = document.getElementById('authVideo');
        video.addEventListener('ended', () => {
            const params = new URLSearchParams(window.location.search);
            const zone = params.get('zone');
            const portalURL = params.get('redirurl');

            let redirectURL = 'login2.html'; // URL padrão

            if (zone) {
                redirectURL = `./login2.html?zone=${zone}&redirurl=${encodeURIComponent(portalURL || '')}`;
            }

            const videoName = 'eld01.mp4'; // ou obtenha dinamicamente se necessário
            redirectURL = `login2.html?video=${encodeURIComponent(videoName)}`;

            window.location.href = redirectURL;
        });

        // Adicionado: fallback para exibir a imagem de fundo
        const videoContainer = document.querySelector('.video-container');
        player.on('ready', () => {
            videoContainer.style.backgroundImage = 'none';
        });

        player.on('error', () => {
            videoContainer.style.backgroundImage = "url('assets/videos/eld01.jpg')";
        });

        // Adicionado: evento de clique para forçar a exibição dos controles
        videoContainer.addEventListener('click', () => {
            player.elements.container.classList.add('plyr--full-ui');
        });
    }, 500);

    const video = document.getElementById('authVideo');
    video.addEventListener('ended', () => {
        const params = new URLSearchParams(window.location.search);
        const zone = params.get('zone');
        const portalURL = params.get('redirurl');

        let redirectURL = 'login2.html'; // URL padrão

        if (zone) {
            redirectURL = `./login2.html?zone=${zone}&redirurl=${encodeURIComponent(portalURL || '')}`;
        }

        const videoName = 'eld01.mp4'; // ou obtenha dinamicamente se necessário
        redirectURL = `login2.html?video=${encodeURIComponent(videoName)}`;

        window.location.href = redirectURL;
    });
});