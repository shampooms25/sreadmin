const VIDEO_EXPIRATION_DAYS = 7; // Configura expiração para 7 dias

function getDeviceId() {
    try {
        let deviceId = localStorage.getItem('deviceId');
        if (!deviceId) {
            deviceId = 'device_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
            localStorage.setItem('deviceId', deviceId);
            // Backup em sessionStorage
            sessionStorage.setItem('deviceId_backup', deviceId);
        }
        return deviceId;
    } catch (error) {
        console.error('Error getting device ID:', error);
        // Tentar recuperar do backup
        return sessionStorage.getItem('deviceId_backup');
    }
}

function isVideoWatchExpired(timestamp) {
    if (!timestamp) return true;
    const now = Date.now();
    const expirationTime = VIDEO_EXPIRATION_DAYS * 24 * 60 * 60 * 1000; // dias em millisegundos
    return (now - timestamp) > expirationTime;
}

function checkVideoStatus() {
    try {
        const deviceId = getDeviceId();
        if (!deviceId) return false;

        const videoWatchKey = `video_watched_${deviceId}`;
        const watchData = localStorage.getItem(videoWatchKey);
        
        if (watchData) {
            const watchInfo = JSON.parse(watchData);
            // Remover verificação de redirecionamento automático
            return watchInfo.completed;
        }
        return false;
    } catch (error) {
        console.error('Error checking video status:', error);
        return false;
    }
}

function clearVideoData(deviceId) {
    try {
        const videoWatchKey = `video_watched_${deviceId}`;
        localStorage.removeItem(videoWatchKey);
        localStorage.removeItem(`${videoWatchKey}_progress`);
    } catch (error) {
        console.error('Error clearing video data:', error);
    }
}

function checkVideoBackup() {
    try {
        const backupData = sessionStorage.getItem('video_backup');
        if (backupData) {
            const backup = JSON.parse(backupData);
            if (backup.completed && !isVideoWatchExpired(backup.timestamp)) {
                window.location.href = 'login.html';
                return true;
            }
        }
        return false;
    } catch (error) {
        console.error('Error checking video backup:', error);
        return false;
    }
}